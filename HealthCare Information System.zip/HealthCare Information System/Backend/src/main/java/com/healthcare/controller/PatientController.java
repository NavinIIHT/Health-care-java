package com.healthcare.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.entity.Patient;
import com.healthcare.service.PatientService;

@RestController
@RequestMapping("/patients")
@CrossOrigin
public class PatientController {
	private final PatientService patientService;

	public PatientController(PatientService patientService) {
		this.patientService = patientService;
	}

	@GetMapping
	public List<Patient> getAllPatients() {
		return patientService.getAllPatients();
	}

	@GetMapping("/{id}")
	public Patient getPatientById(@PathVariable Long id) {
		return patientService.getPatientById(id);
	}

	@PutMapping("/{id}")
	public Patient updatePatient(@PathVariable Long id, @RequestBody Patient updatedPatient) {
		return patientService.updatePatient(id, updatedPatient);
	}

	@GetMapping("/doctor/{doctorId}")
	public List<Patient> getPatientsByDoctorId(@PathVariable Long doctorId) {
		return patientService.getPatientsByDoctorId(doctorId);
	}

	@PostMapping
	public Patient savePatient(@RequestBody Patient patient) {
		return patientService.savePatient(patient);
	}

	@DeleteMapping("/{id}")
	public void deletePatientById(@PathVariable Long id) {
		patientService.deletePatientById(id);
	}

	@GetMapping("/search")
	public List<Patient> searchPatientsByName(@RequestParam String name) {
		return patientService.searchPatientsByName(name);
	}

	@GetMapping("/searchByDoctor")
	public List<Patient> searchPatientsByDoctorIdOrName(@RequestParam String name) {
		return patientService.searchPatientsByDoctorName(name);
	}
}

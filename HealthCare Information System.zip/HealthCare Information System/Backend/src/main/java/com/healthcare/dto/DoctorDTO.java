package com.healthcare.dto;

public class DoctorDTO {
	private Long id;
	private String name;
	private Long hospitalId;

	public DoctorDTO() {
		super();
	}

	public DoctorDTO(Long id, String name, Long hospitalId) {
		super();
		this.id = id;
		this.name = name;
		this.hospitalId = hospitalId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(Long hospitalId) {
		this.hospitalId = hospitalId;
	}

}
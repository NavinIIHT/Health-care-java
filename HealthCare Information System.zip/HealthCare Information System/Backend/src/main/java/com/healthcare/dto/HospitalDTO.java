package com.healthcare.dto;

public class HospitalDTO {
	private Long id;
	private String name;

	public HospitalDTO(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public HospitalDTO() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
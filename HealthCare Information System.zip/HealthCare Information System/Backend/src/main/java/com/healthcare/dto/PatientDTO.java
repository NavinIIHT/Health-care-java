package com.healthcare.dto;

public class PatientDTO {
	private Long id;
	private String name;
	private Long doctorId;

	public PatientDTO() {
		super();
	}

	public PatientDTO(Long id, String name, Long doctorId) {
		super();
		this.id = id;
		this.name = name;
		this.doctorId = doctorId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(Long doctorId) {
		this.doctorId = doctorId;
	}
}
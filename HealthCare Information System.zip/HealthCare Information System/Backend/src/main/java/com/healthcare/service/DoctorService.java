package com.healthcare.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthcare.dto.HospitalDTO;
import com.healthcare.entity.Doctor;
import com.healthcare.entity.Hospital;
import com.healthcare.exception.ResourceNotFoundException;
import com.healthcare.repo.DoctorDAO;

@Service
public class DoctorService {
	private final DoctorDAO doctorDAO;
	private final HospitalService hospitalService;

	@Autowired
	private ModelMapper modelMapper;

	public DoctorService(DoctorDAO doctorDAO, HospitalService hospitalService) {
		this.doctorDAO = doctorDAO;
		this.hospitalService = hospitalService;
	}

	public List<Doctor> getAllDoctors() {
		return doctorDAO.findAll();
	}

	public Doctor getDoctorById(Long id) {
		return doctorDAO.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Doctor not found with ID: " + id));
	}

	public Doctor updateDoctor(Long id, Doctor updatedDoctor) {
		Doctor doctor = getDoctorById(id);
		if (doctor != null) {
			doctor.setName(updatedDoctor.getName());
			// Update other fields as needed
			return doctorDAO.save(doctor);
		}
		return null;
	}

	public List<Doctor> getDoctorsByHospitalId(Long hospitalId) {
		return doctorDAO.findByHospitalId(hospitalId);
	}

	public Doctor saveDoctor(Doctor doctor) {
		HospitalDTO hospitalDTO = hospitalService.getHospitalById(doctor.getHospital().getId());
		Hospital hospital = modelMapper.map(hospitalDTO, Hospital.class);
		if (hospital != null) {
			doctor.setHospital(hospital);
			return doctorDAO.save(doctor);
		}
		return null;
	}

	public void deleteDoctorById(Long id) {
		doctorDAO.deleteById(id);
	}

	public List<Doctor> searchDoctorsByName(String name) {
		return doctorDAO.findByNameContainingIgnoreCase(name);
	}

	public List<Doctor> searchDoctorsByHospitalIdOrName(Long hospitalId, String name) {
		return doctorDAO.findByHospitalIdOrNameContainingIgnoreCase(hospitalId, name);
	}
}
package com.healthcare.service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthcare.dto.HospitalDTO;
import com.healthcare.entity.Hospital;
import com.healthcare.exception.ResourceNotFoundException;
import com.healthcare.repo.HospitalDAO;

@Service
public class HospitalService {
	private final HospitalDAO hospitalDAO;

	@Autowired
	private ModelMapper modelMapper;

	public HospitalService(HospitalDAO hospitalDAO) {
		this.hospitalDAO = hospitalDAO;
	}

	public List<Hospital> getAllHospitals() {
		return hospitalDAO.findAll();
	}

	public HospitalDTO getHospitalById(Long id) {
		Optional<Hospital> optionalHospital = hospitalDAO.findById(id);
		if (optionalHospital.isPresent()) {
			HospitalDTO hospitalDTO = new HospitalDTO();
			BeanUtils.copyProperties(optionalHospital.get(), hospitalDTO);
			return hospitalDTO;
		} else {
			throw new ResourceNotFoundException("Hospital not found with id: " + id);
		}
	}

	public Hospital updateHospital(Long id, Hospital updatedHospital) {
		HospitalDTO hospitalDTO = getHospitalById(id);
		Hospital hospital = modelMapper.map(hospitalDTO, Hospital.class);
		if (hospital != null) {
			hospital.setName(updatedHospital.getName());
			// Update other fields as needed
			return hospitalDAO.save(hospital);
		}
		return null;
	}

	public Hospital saveHospital(Hospital hospital) {
		return hospitalDAO.save(hospital);
	}

	public void deleteHospitalById(Long id) {
		hospitalDAO.deleteById(id);
	}

	public List<Hospital> searchHospitalsByName(String name) {
		return hospitalDAO.findByNameContainingIgnoreCase(name);
	}
}
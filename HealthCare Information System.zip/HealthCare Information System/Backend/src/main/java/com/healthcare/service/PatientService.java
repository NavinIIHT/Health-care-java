package com.healthcare.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.healthcare.entity.Doctor;
import com.healthcare.entity.Patient;
import com.healthcare.exception.ResourceNotFoundException;
import com.healthcare.repo.PatientDAO;

@Service
public class PatientService {
	private final PatientDAO patientDAO;
	private final DoctorService doctorService;

	public PatientService(PatientDAO patientDAO, DoctorService doctorService) {
		this.patientDAO = patientDAO;
		this.doctorService = doctorService;
	}

	public List<Patient> getAllPatients() {
		return patientDAO.findAll();
	}

	public Patient getPatientById(Long id) {
		return patientDAO.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Patient not found with ID: " + id));
	}

	public List<Patient> getPatientsByDoctorId(Long doctorId) {
		return patientDAO.findByDoctorId(doctorId);
	}

	public Patient updatePatient(Long id, Patient updatedPatient) {
		Patient patient = getPatientById(id);
		if (patient != null) {
			patient.setName(updatedPatient.getName());
			// Update other fields as needed
			return patientDAO.save(patient);
		}
		return null;
	}

	public Patient savePatient(Patient patient) {
		Doctor doctor = doctorService.getDoctorById(patient.getDoctor().getId());
		if (doctor != null) {
			patient.setDoctor(doctor);
			return patientDAO.save(patient);
		}
		return null;
	}

	public void deletePatientById(Long id) {
		patientDAO.deleteById(id);
	}

	public List<Patient> searchPatientsByName(String name) {
		return patientDAO.findByNameContainingIgnoreCase(name);
	}

	public List<Patient> searchPatientsByDoctorName(String name) {
		return patientDAO.findByNameContainingIgnoreCase(name);
	}
}